/*
 *  Template MIB group interface - logmatch.h
 *
 */
#ifndef _MIBGROUP_LOGMATCH_H
#define _MIBGROUP_LOGMATCH_H

config_require(util_funcs/header_generic)
config_require(util_funcs/header_simple_table)

void init_logmatch(void);

#endif                          /* _MIBGROUP_LOGMATCH_H */
