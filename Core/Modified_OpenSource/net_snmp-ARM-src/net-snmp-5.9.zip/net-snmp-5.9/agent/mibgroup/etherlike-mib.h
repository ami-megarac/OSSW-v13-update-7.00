/*
 * module to include the modules
 */

config_require(etherlike-mib/dot3StatsTable)
config_add_mib(EtherLike-MIB)

