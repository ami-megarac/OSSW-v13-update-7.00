config_require(mibII/updates)

void            init_snmp_mib(void);
